import { getRequestConfig } from "next-intl/server";
import { notFound } from "next/navigation";

export const locales = ["uk", "en", "ru"] as const;

export default getRequestConfig(async ({ locale }) => {
  // Перевірка на валідність locale
  if (!locale || !locales.includes(locale as any)) {
    notFound();
  }

  try {
    const messages = {
      ...(await import(`./messages/${locale}/common.json`)).default,
      ...(await import(`./messages/${locale}/navigation.json`)).default,
      ...(await import(`./messages/${locale}/footer.json`)).default,
      ...(await import(`./messages/${locale}/home.json`)).default,

      courses: {
        foodSafetyManagement: (
          await import(
            `./messages/${locale}/courses/food-safety-management.json`
          )
        ).default,

        riskManagement: (
          await import(`./messages/${locale}/courses/risk-management.json`)
        ).default,
      },
    };

    return {
      locale, // Тепер TypeScript знає, що locale - це string
      messages,
    };
  } catch (error) {
    console.error(`Failed to load messages for locale: ${locale}`, error);
    notFound();
  }
});
