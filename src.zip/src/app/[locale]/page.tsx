// \src\app\[locale]

import { useTranslations } from 'next-intl';
import Link from 'next/link';

export default function HomePage() {
  const t = useTranslations();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 dark:from-blue-900 dark:to-slate-900 py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center">
            <div className="mb-4 inline-flex items-center rounded-full bg-white/10 px-4 py-1.5 text-sm font-medium text-white backdrop-blur-sm">
              <span>🎓</span>
              <span className="ml-2">Професійний портал з експертизи</span>
            </div>
            <h1 className="text-4xl font-bold text-white md:text-5xl lg:text-6xl">
              Експертиза
              <br />
              <span className="text-blue-200">харчових продуктів</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-blue-100">
              Платформа для стандартів харчової безпеки, систем менеджменту, 
              лабораторних досліджень та освітніх матеріалів.
            </p>
            <div className="mt-10 flex justify-center gap-4">
              <Link
                href="/uk/education"
                className="rounded-lg bg-white px-8 py-3 text-base font-semibold text-blue-600 shadow-lg transition-all hover:bg-blue-50 hover:shadow-xl"
              >
                Почати навчання
              </Link>
              <Link
                href="/uk/standards"
                className="rounded-lg border-2 border-white/30 bg-white/10 px-8 py-3 text-base font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/20"
              >
                Переглянути стандарти
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
          <div className="rounded-2xl bg-white p-8 text-center shadow-md dark:bg-slate-900">
            <div className="text-4xl font-bold text-blue-600 dark:text-blue-400">8</div>
            <div className="mt-2 text-sm text-slate-600 dark:text-slate-400">Стандартів</div>
          </div>
          <div className="rounded-2xl bg-white p-8 text-center shadow-md dark:bg-slate-900">
            <div className="text-4xl font-bold text-green-600 dark:text-green-400">6</div>
            <div className="mt-2 text-sm text-slate-600 dark:text-slate-400">Систем</div>
          </div>
          <div className="rounded-2xl bg-white p-8 text-center shadow-md dark:bg-slate-900">
            <div className="text-4xl font-bold text-purple-600 dark:text-purple-400">132</div>
            <div className="mt-2 text-sm text-slate-600 dark:text-slate-400">Матеріалів</div>
          </div>
        </div>
      </div>

      {/* Modules Section */}
      <div className="mx-auto max-w-7xl px-6 pb-20">
        <h2 className="mb-8 text-3xl font-bold text-slate-900 dark:text-white">
          Розділи порталу
        </h2>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Link
            href="/uk/education"
            className="group rounded-2xl bg-white p-6 shadow-md transition-all hover:-translate-y-1 hover:shadow-xl dark:bg-slate-900"
          >
            <div className="mb-4 text-4xl">📚</div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Навчання
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              Освітні матеріали, курси та кейси для студентів та спеціалістів.
            </p>
            <div className="mt-4 text-sm font-semibold text-blue-600 group-hover:translate-x-1 dark:text-blue-400">
              Перейти →
            </div>
          </Link>

          <Link
            href="/uk/standards"
            className="group rounded-2xl bg-white p-6 shadow-md transition-all hover:-translate-y-1 hover:shadow-xl dark:bg-slate-900"
          >
            <div className="mb-4 text-4xl">📋</div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Стандарти
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              Нормативні документи, ДСТУ, технічні регламенти та законодавство.
            </p>
            <div className="mt-4 text-sm font-semibold text-blue-600 group-hover:translate-x-1 dark:text-blue-400">
              Перейти →
            </div>
          </Link>

          <Link
            href="/uk/systems"
            className="group rounded-2xl bg-white p-6 shadow-md transition-all hover:-translate-y-1 hover:shadow-xl dark:bg-slate-900"
          >
            <div className="mb-4 text-4xl">🏗️</div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Системи менеджменту
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              HACCP, ISO 22000, FSSC 22000, BRCGS, IFS та інші системи безпеки.
            </p>
            <div className="mt-4 text-sm font-semibold text-blue-600 group-hover:translate-x-1 dark:text-blue-400">
              Перейти →
            </div>
          </Link>

          <Link
            href="/uk/laboratory"
            className="group rounded-2xl bg-white p-6 shadow-md transition-all hover:-translate-y-1 hover:shadow-xl dark:bg-slate-900"
          >
            <div className="mb-4 text-4xl">🔬</div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Лабораторія
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              Методи мікробіологічних, хімічних та фізико-хімічних досліджень.
            </p>
            <div className="mt-4 text-sm font-semibold text-blue-600 group-hover:translate-x-1 dark:text-blue-400">
              Перейти →
            </div>
          </Link>

          <Link
            href="/uk/glossary"
            className="group rounded-2xl bg-white p-6 shadow-md transition-all hover:-translate-y-1 hover:shadow-xl dark:bg-slate-900"
          >
            <div className="mb-4 text-4xl">📖</div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Глосарій
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              Тлумачення термінів та визначень у сфері харчової безпеки.
            </p>
            <div className="mt-4 text-sm font-semibold text-blue-600 group-hover:translate-x-1 dark:text-blue-400">
              Перейти →
            </div>
          </Link>

          <Link
            href="/uk/about"
            className="group rounded-2xl bg-white p-6 shadow-md transition-all hover:-translate-y-1 hover:shadow-xl dark:bg-slate-900"
          >
            <div className="mb-4 text-4xl">ℹ️</div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Про нас
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              Інформація про портал, авторів та установу.
            </p>
            <div className="mt-4 text-sm font-semibold text-blue-600 group-hover:translate-x-1 dark:text-blue-400">
              Перейти →
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}